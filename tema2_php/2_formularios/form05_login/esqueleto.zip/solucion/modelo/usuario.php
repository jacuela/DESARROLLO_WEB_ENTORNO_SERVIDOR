<?php

//Si quiero poder convertir a json el objeto con json_encode puedo:
//- hacer atributos publicos. Sencillo, pero no profesional
//- si los atributos son privados, debo implementar la interfaz JsonSerializable

class Usuario
{
    private $nombre;
    private $email;
    private $password; //guardaré un hash
    
}

