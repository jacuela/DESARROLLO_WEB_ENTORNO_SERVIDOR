<header>
  <h1>ALTA Y LOGIN DE USUARIOS</h1>
</header>
<nav>
  <ul>
    <li class="izda"><a class="menu" href="index.php">Home</a></li>
    <li class="izda"><a class="menu" href="alta.php">Alta</a></li>
    <li class="drcha"><a class='menu' href='login.php'>Login</a></li>
   </ul>
  <br>
</nav>