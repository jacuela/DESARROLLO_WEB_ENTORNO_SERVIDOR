<footer>
    <p>&reg; Creado por: <strong>Juan Antonio Cuello </strong></p>
    <p>Asignatura: Desarrollo web entorno Servidor &#x1f9e1;</p>
    <?php echo date("Y"); ?>
</footer>