<?php

$usuario_valido = "admin";
$clave_valida = "1234";

?>