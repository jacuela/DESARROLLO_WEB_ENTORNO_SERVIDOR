<?php

$dbMotor = "mysql";
$mysqlHost = "127.0.0.1";
$mysqlUser = "root";
$mysqlPassword = "";
$mysqlDatabase = "usuariosDB";


