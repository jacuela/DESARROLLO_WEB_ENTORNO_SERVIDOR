<header> <h1>CRUD USUARIOS</h1></header>
<nav>
  <ul>
    <li><a href="listado.php">Listado</a></li>
    <li><a href="alta.php">Alta de Usuario</a></li>
  </ul>
  <br>
</nav>


