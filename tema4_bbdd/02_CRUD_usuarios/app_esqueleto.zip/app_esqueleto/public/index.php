<?php 

//Nos conectamos a la base de datos

//Si has conectado bien, te vas a listado.php

?>

