<?php

$dbMotor = "";
$mysqlHost = "127.0.0.1";
$mysqlUser = "";
$mysqlPassword = "";
$mysqlDatabase = "";


