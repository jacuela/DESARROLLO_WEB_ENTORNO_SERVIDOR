<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD usuarios</title>
</head>
<body>
    
    <h2>Detalles del usuario</h2>
    <p><b>ID:</b></p>
    <p><b>Nombre:</b></p>
    <p><b>Apellidos:</b></p>
    <p><b>Usuario:</b></p>
    <p><b>Fecha nacimiento:</b></p>
    <p><b>Edad:</b></p>
    
    
</body>
</html>