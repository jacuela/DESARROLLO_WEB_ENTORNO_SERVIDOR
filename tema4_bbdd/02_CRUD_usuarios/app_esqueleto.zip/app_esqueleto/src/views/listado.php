
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD usuarios</title>
    <link rel="stylesheet" href="../../public/css/style.css">
</head>
<body>
    
    <h2>Listado de usuarios</h2>

    <table border="1" class="tabla">
        <thead>
            <tr>
                <th>NOMBRE</th>
                <th>APELLIDOS</th>
                <th>USUARIO</th>
                <th>FECHA_NAC</th>
                <th>EDAD</th>
                <th>ACCION</th>
            </tr>
        </thead>
        <tbody>
            ...
        </tbody>






    </table>



    
</body>
</html>