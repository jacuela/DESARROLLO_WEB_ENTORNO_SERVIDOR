<header> <h1>CRUD USUARIOS</h1></header>
<nav>
  <ul>
    <li><a href="XXXXXX">Listado</a></li>
    <li><a href="XXXXXXX">Alta de Usuario</a></li>
  </ul>
  <br>
</nav>


