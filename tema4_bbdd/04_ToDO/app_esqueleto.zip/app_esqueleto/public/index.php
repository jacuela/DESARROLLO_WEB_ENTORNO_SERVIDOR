<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>ToDO</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?= $mensaje ?> 
</body>
</html>